#!/usr/bin/env python3
"""15% MAF-threshold sensitivity analysis for existing INSIGHT pipeline.
Run from working directory with original beta-generation script and inputs.
Does NOT modify original files.
"""
from pathlib import Path
import re
import subprocess
import sys

beta_source = Path('estimate_insight_beta.py')
poly_source = Path('poly.sorted.bed')
inputs = [Path('INSIGHT_HI_CDS_PhyloPgt2.input.txt'), Path('INSIGHT_CDS_PhyloPgt2_input.txt')]
exe = Path('bin/INSIGHT-EM-v1.1')
for p in (beta_source, poly_source, exe):
    if not p.is_file():
        sys.exit(f'ERROR: missing {p}')
if not any(p.is_file() for p in inputs):
    sys.exit('ERROR: neither selected-site INSIGHT input is present')

# Recreate neutral beta data with consistent 15% minor-allele-frequency threshold.
source = beta_source.read_text()
old = "cls='L' if maf<0.1 else 'H'"
if source.count(old) != 1:
    sys.exit('ERROR: unexpected beta script version; cannot safely modify cutoff')
modified = Path('estimate_insight_beta_15pct.py')
modified.write_text(source.replace(old, "cls='L' if maf<0.15 else 'H'"))
print('Recomputing neutral beta at 15% MAF...', flush=True)
subprocess.run([sys.executable, str(modified), '--prefix', 'neutral_beta_15pct'], check=True)
with open('neutral_beta_15pct.beta_em.log', 'w') as log:
    subprocess.run([str(exe), '-b', 'neutral_beta_15pct.forBetas.ins', '-v'], stdout=log, stderr=subprocess.STDOUT, check=True)
log = Path('neutral_beta_15pct.beta_em.log').read_text()
m = re.search(r'^Estimates:\s+([0-9.eE+-]+)', log, re.M)
if not m or not re.search(r'^EM status:.*\bconverged\b', log, re.M):
    sys.exit('ERROR: beta EM did not converge; inspect neutral_beta_15pct.beta_em.log')
r = float(m.group(1))
values = dict(line.split() for line in Path('neutral_beta_15pct.beta2.txt').read_text().splitlines() if line.strip())
b = float(values['beta2'])
beta1, beta2, beta3 = r * (1-b), b, (1-r)*(1-b)
print(f'15% beta: {beta1:.10f} {beta2:.10f} {beta3:.10f}', flush=True)
Path('neutral_beta_15pct.final_beta.txt').write_text(f'beta {beta1:.10f} {beta2:.10f} {beta3:.10f}\n')

# Read variant MAFs from existing nonsynonymous polymorphism calls.
# poly.sorted.bed: chr, start, end, phyloP, gene, MAF, DAF, theta, lambda.
maf_by_site = {}
with poly_source.open() as fh:
    for line in fh:
        x = line.split()
        if len(x) < 7:
            continue
        try:
            maf = float(x[5])
        except ValueError:
            continue
        key = f'{x[0]}:{x[2]}'
        if key in maf_by_site and abs(maf_by_site[key]-maf)>1e-8:
            sys.exit(f'ERROR: conflicting MAF values for {key}')
        maf_by_site[key] = maf
print(f'Loaded {len(maf_by_site):,} polymorphic positions', flush=True)

for original in inputs:
    if not original.is_file():
        continue
    output = original.with_name(original.name.replace('.input.txt', '.MAF15.input.txt').replace('_input.txt', '_MAF15_input.txt'))
    result_log = original.with_name(output.name.replace('.input.txt', '.log').replace('_input.txt', '.log'))
    n_changed = n_poly = n_missing = n_sites = n_beta = 0
    with original.open() as src, output.open('w') as out:
        for line in src:
            x = line.split()
            if x and x[0] == 'beta':
                n_beta += 1
                continue
            if x and x[0] == 'samples':
                out.write(line)
                out.write(f'beta {beta1:.10f} {beta2:.10f} {beta3:.10f}\n')
                continue
            if len(x)>=5 and x[0]=='site' and x[2] in ('L','H'):
                n_poly += 1
                maf = maf_by_site.get(x[1])
                if maf is None:
                    n_missing += 1
                else:
                    classification = 'L' if maf < 0.15 else 'H'
                    if x[2] != classification:
                        n_changed += 1
                    x[2] = classification
                    line = ' '.join(x) + '\n'
            if x and x[0]=='site':
                n_sites += 1
            out.write(line)
    if n_missing:
        sys.exit(f'ERROR: {n_missing} selected polymorphisms missing from poly.sorted.bed; investigate {output}')
    if not n_sites or not n_poly:
        sys.exit(f'ERROR: no sites or polymorphisms in {output}')
    print(f'{output}: {n_sites:,} sites, {n_poly:,} polymorphisms, {n_changed:,} relabeled L/H; removed {n_beta} old beta line(s)', flush=True)
    print(f'Running INSIGHT on {output}...', flush=True)
    with result_log.open('w') as log_out:
        subprocess.run([str(exe), str(output), '-v'], stdout=log_out, stderr=subprocess.STDOUT, check=True)
    print(f'Log: {result_log}', flush=True)
    for line in result_log.read_text().splitlines():
        if line.lstrip().startswith(('Estimates:', 'StndrdErr:', 'EM status:')):
            print(line)
