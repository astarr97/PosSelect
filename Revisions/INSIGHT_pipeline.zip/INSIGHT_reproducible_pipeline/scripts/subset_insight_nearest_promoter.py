#!/usr/bin/env python3
"""Subset INSIGHT input to sites whose nearest promoter (among ALL promoters) belongs to target genes.

Requires bedtools closest. Streams through a temporary site BED, then a 1-byte-per-site mask.
INSIGHT input layout: samples/beta lines, block chr:start-end ..., site chr:pos ...
"""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile
from collections import Counter

TARGETS = '''KDM5C ACOX1 AHSG OFD1 ATRX UROC1 SUCLA2 AP4M1 SNAP29 RAB3GAP2 COX7B NKX2-5 CTSD DDB2 DMPK ERCC2 ERCC3 ERCC4 ERCC5 WDR81 SLC9A6 GCH1 HCCS KCNH1 MECP2 MGAT2 MTRR NDP TONSL PEX1 NDUFB11 NDE1 CC2D1A PTS B3GLCT SRD5A3 SLC35C1 L2HGDH ARX SLC16A2 ARHGEF9 TCF4 TK2 KAT6B TSHB UBE3A XPA XPC'''.split()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', default='INSIGHT_NC_PhyloPgt2_corrected.input.txt')
    p.add_argument('--promoters', default='../../../AccelEvol/AccelEvol_New/Human_Promoters_Ortho_Sorted_hg38.sort.bed')
    p.add_argument('--output', default='INSIGHT_NC_PhyloPgt2_corrected.nearest_gene_panel.input.txt')
    p.add_argument('--tmpdir', default=None)
    a = p.parse_args()
    targets = set(TARGETS)
    for path in (a.input, a.promoters):
        if not os.path.isfile(path):
            p.error(f'Missing required file: {path}')
    if os.path.abspath(a.input) == os.path.abspath(a.output):
        p.error('Output must differ from input')

    with tempfile.TemporaryDirectory(prefix='insight_nearest_', dir=a.tmpdir) as tmp:
        sites_bed = Path(tmp) / 'sites.bed'
        marks = Path(tmp) / 'keep.bin'
        counts = Counter()
        # Retain a one-to-one mapping between site records and BED intervals.
        with open(a.input) as src, sites_bed.open('w') as sites:
            for line in src:
                parts = line.split()
                if parts and parts[0] == 'site':
                    chrom, pos = parts[1].rsplit(':', 1)
                    pos = int(pos)
                    if pos < 1:
                        raise ValueError(f'Invalid 1-based INSIGHT coordinate: {parts[1]}')
                    sites.write(f'{chrom}\t{pos-1}\t{pos}\n')
                    counts['input_sites'] += 1
        print(f"Site intervals: {counts['input_sites']:,}; running nearest-promoter assignment", flush=True)
        # -t first resolves equidistant promoters by their existing BED order.
        # All promoters must be present here; filtering promoters first is WRONG.
        with marks.open('wb') as m:
            cmd = ['bedtools', 'closest', '-a', str(sites_bed), '-b', a.promoters, '-d', '-t', 'first']
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, universal_newlines=True)
            try:
                for row in proc.stdout:
                    fields = row.rstrip('\n').split('\t')
                    if len(fields) < 8:
                        raise ValueError(f'Unexpected bedtools closest row: {row[:250]}')
                    gene = fields[6] # 3 site columns + B chrom/start/end + B gene
                    keep = gene in targets
                    m.write(b'1' if keep else b'0')
                    counts['checked'] += 1
                    if keep:
                        counts['selected_sites'] += 1
                        counts[f'gene:{gene}'] += 1
                rc = proc.wait()
                if rc != 0:
                    raise RuntimeError(f'bedtools closest exited with status {rc}')
            finally:
                if proc.poll() is None:
                    proc.kill()
                    proc.wait()
        if counts['checked'] != counts['input_sites']:
            raise RuntimeError(f"Nearest-site rows mismatch: {counts['checked']} vs {counts['input_sites']}")
        print(f"Sites assigned to selected genes: {counts['selected_sites']:,}", flush=True)
        # Buffer each block line until we encounter its first retained site.
        # Do NOT retain a block with zero selected sites.
        with open(a.input) as src, marks.open('rb') as m, open(a.output, 'w') as dst:
            pending_block = None
            block_written = False
            for line in src:
                fields = line.split()
                if not fields:
                    continue
                if fields[0] == 'block':
                    pending_block = line
                    block_written = False
                elif fields[0] == 'site':
                    flag = m.read(1)
                    if not flag:
                        raise RuntimeError('Ran out of per-site mask values')
                    if flag == b'1':
                        if pending_block is None:
                            raise RuntimeError('Site encountered before block')
                        if not block_written:
                            dst.write(pending_block)
                            block_written = True
                            counts['selected_blocks'] += 1
                        dst.write(line)
                else:
                    # Retain sample/beta and other global headers.
                    if pending_block is None:
                        dst.write(line)
            if m.read(1):
                raise RuntimeError('Extra mask values remained after processing')
    print(f"Selected blocks: {counts['selected_blocks']:,}")
    print(f"Output: {a.output}")
    print('Gene counts (selected sites):')
    for gene in TARGETS:
        print(f'{gene}\t{counts[f"gene:{gene}"]}')
    missing = [g for g in TARGETS if counts[f'gene:{g}'] == 0]
    print('Genes with zero sites:', ', '.join(missing) if missing else 'none')


if __name__ == '__main__':
    main()
