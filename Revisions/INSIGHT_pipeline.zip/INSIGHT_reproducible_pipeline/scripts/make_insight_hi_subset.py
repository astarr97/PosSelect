#!/usr/bin/env python3
"""Prepare a CDS/PhyloP>2 INSIGHT subset for the provided HI gene list.

Run from the existing INSIGHT working directory. Reuses the original
make_INSIGHT.py, theta.sorted.bed, lambda.sorted.bed, poly.sorted.bed,
and fixed.sorted.bed without modifying those inputs.
"""
import argparse
import bisect
from collections import Counter, defaultdict
from pathlib import Path
import re
import subprocess
import sys

DEFAULT_ALLSITES = 'PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed'
DEFAULT_PREFIX = 'INSIGHT_HI_CDS_PhyloPgt2'
BETA = (0.8269735927067247, 0.14942289256186714, 0.02360351473140823)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--genes', default='NonsynDep2_HI_Genes.txt')
    parser.add_argument('--gtf', default='/oak/stanford/groups/hbfraser/astarr/human.gtf')
    parser.add_argument('--allsites', default=DEFAULT_ALLSITES)
    parser.add_argument('--prefix', default=DEFAULT_PREFIX)
    args = parser.parse_args()
    for path in [args.genes, args.gtf, args.allsites, 'make_INSIGHT.py',
                 'theta.sorted.bed', 'lambda.sorted.bed',
                 'poly.sorted.bed', 'fixed.sorted.bed']:
        if not Path(path).is_file():
            parser.error(f'missing input: {path}')

    genes = {line.strip() for line in Path(args.genes).read_text().splitlines()
             if line.strip() and not line.lstrip().startswith('#')}
    if not genes:
        parser.error('empty gene list')
    # Apply gene symbol matching exactly; do NOT select related/prefix symbols.
    gene_rx = re.compile(r'(?:^|;)\s*gene_name "([^"]+)"')
    transcript_rx = re.compile(r'(?:^|;)\s*transcript_type "([^"]+)"')
    by_chrom = defaultdict(list)
    gene_cds = set()
    with open(args.gtf) as inf:
        for line in inf:
            if line.startswith('#'):
                continue
            fields = line.rstrip('\n').split('\t')
            if len(fields) < 9 or fields[2] != 'CDS':
                continue
            gm = gene_rx.search(fields[8])
            tm = transcript_rx.search(fields[8])
            if not gm or gm.group(1) not in genes or not tm or tm.group(1) != 'protein_coding':
                continue
            chrom = fields[0]
            if not (chrom.startswith('chr') and chrom[3:] in {str(i) for i in range(1,23)} | {'X','Y'}):
                continue
            start, end = int(fields[3])-1, int(fields[4])
            by_chrom[chrom].append((start, end))
            gene_cds.add(gm.group(1))

    merged = {}
    for chrom, ranges in by_chrom.items():
        ranges.sort()
        merged_ranges = []
        for start, end in ranges:
            if merged_ranges and start <= merged_ranges[-1][1]:
                merged_ranges[-1] = (merged_ranges[-1][0], max(merged_ranges[-1][1], end))
            else:
                merged_ranges.append((start, end))
        merged[chrom] = ([a for a, b in merged_ranges], [b for a, b in merged_ranges])

    print(f'Gene list: {len(genes)} unique symbols; {len(gene_cds)} with protein-coding CDS in GTF', flush=True)
    unmatched = sorted(genes - gene_cds)
    Path(f'{args.prefix}.genes_without_CDS.txt').write_text('\n'.join(unmatched) + ('\n' if unmatched else ''))
    out_sites = f'{args.prefix}.AllSites_CDS.bed'
    counts = Counter()
    last = None
    with open(args.allsites) as inp, open(out_sites, 'w') as out:
        for line in inp:
            x = line.rstrip('\n').split('\t')
            counts['allsite_rows'] += 1
            if len(x) < 7 or x[3] not in merged:
                continue
            try:
                site_start, site_end = int(x[4]), int(x[5])
                phylo = float(x[6])
            except ValueError:
                continue
            if phylo <= 2 or site_end - site_start != 1:
                continue
            starts, ends = merged[x[3]]
            i = bisect.bisect_right(starts, site_start) - 1
            if i < 0 or site_end > ends[i]:
                continue
            key = (x[3], site_start, site_end)
            if key == last:
                counts['duplicate_site_rows_skipped'] += 1
                continue
            last = key
            # The legacy generator requires 7+ columns, with block in 1-3,
            # site in 4-6 and PhyloP in 7. Preserve overlap as column 8.
            out.write('\t'.join(x[:8]) + '\n' if len(x) >= 8 else '\t'.join(x[:7] + ['1']) + '\n')
            counts['selected_sites'] += 1
    if not counts['selected_sites']:
        sys.exit('ERROR: zero selected sites; verify GTF version/chromosome names/site intervals')

    original = Path('make_INSIGHT.py').read_text()
    replacement = f'{args.prefix}.input.txt'
    if f'allsites = "{DEFAULT_ALLSITES}"' not in original or 'outfile = "INSIGHT_input.txt"' not in original:
        sys.exit('ERROR: cannot recognize expected input/output declarations in make_INSIGHT.py; no run attempted')
    modified = original.replace(f'allsites = "{DEFAULT_ALLSITES}"', f'allsites = "{out_sites}"', 1)
    modified = modified.replace('outfile = "INSIGHT_input.txt"', f'outfile = "{replacement}"', 1)
    runner = Path(f'{args.prefix}.generator.py')
    runner.write_text(modified)
    print(f'Selected {counts["selected_sites"]:,} PhyloP>2 CDS sites; generating INSIGHT input...', flush=True)
    subprocess.run([sys.executable, str(runner)], check=True)

    inp = Path(replacement)
    temp = inp.with_suffix('.tmp')
    classes = Counter()
    with inp.open() as src, temp.open('w') as dest:
        for line in src:
            dest.write(line)
            if line.startswith('samples '):
                dest.write('beta ' + ' '.join(f'{v:.12f}' for v in BETA) + '\n')
            elif line.startswith('site '):
                f = line.split()
                classes['L' if f[2] == 'L' else 'H' if f[2] == 'H' else 'D' if float(f[3]) < .5 else 'I'] += 1
            elif line.startswith('block '):
                classes['blocks'] += 1
    temp.replace(inp)
    print('INSIGHT input:', replacement)
    print('Site counts:', dict(classes))
    if sum(classes[k] for k in ('L','H','D','I')) != counts['selected_sites']:
        sys.exit('WARNING: generated site count differs from selected site count; inspect skipped blocks/inputs')
    print('Genes absent from matching CDS annotations:', len(unmatched), f'(see {args.prefix}.genes_without_CDS.txt)')
    print('Run: ./bin/INSIGHT-EM-v1.1 ' + replacement + ' -v > ' + args.prefix + '.log 2>&1')
    print('CAUTION: Existing poly/fixed BEDs are nonsynonymous-only; input is CDS-wide.')
    print('CAUTION: AllSites includes only blocks selected by the original variant-driven pipeline.')

if __name__ == '__main__':
    main()
