#!/usr/bin/env bash
set -euo pipefail
# Uses existing poly.both.tmp.bed, fixed.support.bed and exon mask.
BASE="${BASE:-INSIGHT_NC_PhyloPgt2}" OUT="${OUT:-INSIGHT_NC_PhyloPgt2_corrected}" bash insight_nc_finish_v2.sh
