#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
GTF="${GTF:-/oak/stanford/groups/hbfraser/astarr/human.gtf}"
ALLSITES="${ALLSITES:-PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed}"
BETA="${BETA:-beta 0.826972593 0.149422893 0.023604515}"
for f in "$GTF" "$ALLSITES" poly.sorted.bed fixed.sorted.bed theta.sorted.bed lambda.sorted.bed make_INSIGHT.py; do test -s "$f" || { echo "Missing $f" >&2; exit 1; }; done
awk -F '\t' 'BEGIN{OFS="\t"} $3=="CDS" && ($9~/transcript_type "protein_coding"/ || $9~/gene_type "protein_coding"/) {print $1,$4-1,$5}' "$GTF" | sort -k1,1 -k2,2n | bedtools merge -i - > INSIGHT_CDS_protein_coding.bed
awk 'BEGIN{OFS="\t"} $7>2 {print $4,$5,$6,$1,$2,$3,$7,1}' "$ALLSITES" | bedtools intersect -sorted -u -a stdin -b INSIGHT_CDS_protein_coding.bed | awk 'BEGIN{OFS="\t"} {print $4,$5,$6,$1,$2,$3,$7,$8}' > INSIGHT_CDS_PhyloPgt2.AllSites.bed
python3 - <<'PY'
from pathlib import Path
s=Path('make_INSIGHT.py').read_text()
r={'PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed':'INSIGHT_CDS_PhyloPgt2.AllSites.bed','INSIGHT_input.txt':'INSIGHT_CDS_PhyloPgt2_input.txt'}
for old,new in r.items():
 assert '"'+old+'"' in s, old
 s=s.replace('"'+old+'"','"'+new+'"')
Path('INSIGHT_CDS_PhyloPgt2.generator.py').write_text(s)
PY
python3 INSIGHT_CDS_PhyloPgt2.generator.py
python3 - "$BETA" <<'PY'
from pathlib import Path
import sys
p=Path('INSIGHT_CDS_PhyloPgt2_input.txt');t=p.with_suffix('.withbeta.tmp');b=sys.argv[1]
with p.open() as src,t.open('w') as out:
 head=src.readline();assert head.startswith('samples ');out.write(head);out.write(b+'\n')
 for line in src:
  if line.startswith('beta '):raise ValueError('beta duplicated')
  out.write(line)
t.replace(p)
PY
echo 'Prepared INSIGHT_CDS_PhyloPgt2_input.txt'
