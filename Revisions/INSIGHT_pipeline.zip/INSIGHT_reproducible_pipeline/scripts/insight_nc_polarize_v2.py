#!/usr/bin/env python3
"""Streaming, position-grouped polarization of 7+9+9 poly or 5+9+9 fixed BED intersections.
Outgroup bases from callSNPsFromMAF.py are already aligned to human bases: NO complementation.
"""
import argparse, collections, math
p=argparse.ArgumentParser()
p.add_argument('mode',choices=['poly','fixed'])
p.add_argument('joined'); p.add_argument('output'); p.add_argument('report')
a=p.parse_args()
pre=7 if a.mode=='poly' else 5
n_expected=pre+18
stats=collections.Counter()

def handle(key, rows, out):
    if not rows:return
    stats['positions_seen']+=1
    # Multiple alignments for the same variant must give consistent ancestral bases.
    by_allele=collections.defaultdict(list)
    for x in rows:
        human_ref=x[4] if a.mode=='poly' else None
        ch=x[pre:pre+9]; go=x[pre+9:pre+18]
        # ch/go: chromosome,start,end,human_base,outgroup_base,outgroup_strand,human_strand,...
        c_ref,c_base=ch[3].upper(),ch[4].upper()
        g_ref,g_base=go[3].upper(),go[4].upper()
        stats['joined_rows']+=1
        if any(len(b)!=1 or b not in 'ACGT' for b in (c_ref,c_base,g_ref,g_base)):
            stats['invalid_aligned_base']+=1;continue
        if a.mode=='poly' and (c_ref!=g_ref or c_ref!=human_ref):
            stats['human_reference_disagreement']+=1;continue
        if c_base!=g_base:
            stats['outgroup_disagreement']+=1;continue
        if a.mode=='poly':
            chrom,start,end,af,ref,alt,maf=x[:7]
            if c_base not in (ref,alt):
                stats['ancestral_not_ref_or_alt']+=1;continue
            try:
                af=float(af);maf=float(maf)
            except ValueError:
                stats['invalid_frequency']+=1;continue
            if not (0<=af<=1 and 0<=maf<=0.5):
                stats['invalid_frequency']+=1;continue
            # Same alt allele can have multiple alignment records; verify ancestry is unambiguous.
            by_allele[(ref,alt)].append((c_base,maf,af))
        else:
            # ReadFast already defines fixed substitutions. Only test chimp/gorilla
            # agreement; do not require outgroups to differ from the human base.
            by_allele[(c_base,)].append((c_base,0,0))
    options=[]
    for variant, calls in by_allele.items():
        ancestries={x[0] for x in calls}
        if len(ancestries)>1:
            stats['conflicting_ancestry_for_allele']+=1;continue
        if a.mode=='poly':
            # Take maximum reported MAF if duplicate annotation rows occur for same REF/ALT.
            anc,maf,af=max(calls,key=lambda x:x[1])
            daf=af if anc==variant[0] else 1-af
            options.append((maf,variant[0],variant[1],daf))
        else: options.append((0,variant[0],variant[0],None))
    if not options:
        stats['positions_rejected']+=1;return
    if a.mode=='poly':
        # Highest MAF at multiallelic positions; deterministic tie-break.
        chosen=sorted(options,key=lambda v:(-v[0],v[1],v[2]))[0]
        if len(options)>1: stats['multiallelic_positions']+=1
        maf,ref,alt,daf=chosen
        out.write(f'{key[0]}\t{key[1]}\t{key[2]}\t0\tNC\t{maf:.12g}\t{daf:.12g}\n')
        if maf>=.1:stats['retained_H']+=1
        else:stats['retained_L']+=1
    else:
        # Reject sites with mutually inconsistent ancestral calls across alignments.
        if len(set(o[1] for o in options))>1:
            stats['fixed_conflicting_alignments']+=1;stats['positions_rejected']+=1;return
        out.write(f'{key[0]}\t{key[1]}\t{key[2]}\n')
    stats['positions_retained']+=1

prev=None;rows=[]
with open(a.joined) as inp,open(a.output,'w') as out:
    for line in inp:
        x=line.rstrip('\n').split('\t')
        if len(x)!=n_expected:raise ValueError(f'Expected {n_expected} columns, found {len(x)}: {line[:200]}')
        key=(x[0],x[1],x[2])
        if prev is not None and key!=prev:
            handle(prev,rows,out);rows=[]
        prev=key;rows.append(x)
    if prev is not None:handle(prev,rows,out)
with open(a.report,'w') as r:
    for k,v in sorted(stats.items()):r.write(f'{k}\t{v}\n')
print(a.mode,dict(stats))
