#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
OUT="${OUT:-INSIGHT_NC_PhyloPgt2_corrected}"
POLY_SRC="${POLY_SRC:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Final_Files_PosSelect/HumanPoly_MAF0.001_AF_Cons_VEP_ChpGorFilt.txt}"
FIXED_SRC="${FIXED_SRC:-HumChp_NC_Final_NoHLA_ReadFast.txt}"
SPEC="${SPEC:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Recomputing447-way_Final/Scores/All.MskHum.SpecSup.G250.bed}"
PHYLOP="${PHYLOP:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Recomputing447-way_Final/Scores/All.MskHum.PhyloP.bed}"
GTF="${GTF:-/oak/stanford/groups/hbfraser/astarr/human.gtf}"
for f in "$POLY_SRC" "$FIXED_SRC" "$SPEC" "$PHYLOP" "$GTF"; do [[ -s "$f" ]] || { echo "Missing $f" >&2; exit 1; }; done
# 1. Parse tab-or-space-delimited human variant table. VEP consequence and biotype lists are paired by index.
python3 - "$POLY_SRC" "$OUT.poly.raw.bed" "$OUT.parse_stats.txt" <<'PY'
import sys,re,collections,math
src,dst,report=sys.argv[1:]
st=collections.Counter()
with open(src) as inp, open(dst,'w') as out:
    for line in inp:
        if not line.strip() or line.startswith('#'): continue
        a=line.split()
        st['source_rows']+=1
        if len(a)<24: st['short_rows']+=1; continue
        m=re.fullmatch(r'(chr[^:]+):(\d+)-(\d+)-([ACGT]+)-([ACGT]+)',a[0])
        if not m or len(m[4])!=1 or len(m[5])!=1 or m[2]!=m[3]: st['non_snv_or_bad_id']+=1; continue
        chrom,pos_s,_,ref,alt=m.groups(); pos=int(pos_s)
        if a[2].upper()!=ref or a[3].upper()!=alt: st['ref_alt_mismatch']+=1; continue
        consequences=a[21].strip(';').split(';')
        biotypes=a[23].strip(';').split(';')
        if len(consequences)!=len(biotypes): st['vep_pair_count_mismatch']+=1; continue
        excluded=False
        for c,b in zip(consequences,biotypes):
            effects=c.split('&')
            if b=='protein_coding' and any(x in ('missense_variant','5_prime_UTR_variant','3_prime_UTR_variant') for x in effects):
                excluded=True; break
        if excluded: st['excluded_protein_coding_missense_or_UTR']+=1; continue
        try: freqs=[float(v) for v in a[4:12]]
        except ValueError: st['bad_frequency']+=1; continue
        if not all(math.isfinite(f) and 0<=f<=1 for f in freqs): st['bad_frequency']+=1; continue
        af=max(freqs)
        maf=min(af,1-af)
        if maf<0.001: st['maf_below_0.001']+=1; continue
        # BED chrom, start, end, ALT frequency, human ref, human alt, max-population MAF.
        out.write(f'{chrom}\t{pos-1}\t{pos}\t{af:.12g}\t{ref}\t{alt}\t{maf:.12g}\n')
        st['passed_VEP_and_MAF']+=1
with open(report,'w') as out:
    for k,v in sorted(st.items()): out.write(f'{k}\t{v}\n')
PY
sort -k1,1 -k2,2n "$OUT.poly.raw.bed" > "$OUT.poly.sorted.bed"

# 2. Convert fixed NC human-derived changes to zero-based BED; require high PhyloP at the variant itself.
python3 - "$FIXED_SRC" "$OUT.fixed.raw.bed" <<'PY'
import sys,re
with open(sys.argv[1]) as inp,open(sys.argv[2],'w') as out:
    for line in inp:
        a=line.split()
        if len(a)<6 or a[0]=='Position': continue
        m=re.fullmatch(r'(chr[^:]+):(\d+)',a[0])
        if not m: continue
        try: pp=float(a[3]); support=float(a[5])
        except ValueError: continue
        if pp>2 and support>250:
            chrom,pos=m[1],int(m[2]); out.write(f'{chrom}\t{pos-1}\t{pos}\t{pp:.12g}\t{a[1]}\n')
PY
sort -k1,1 -k2,2n "$OUT.fixed.raw.bed" > "$OUT.fixed.sorted.bed"

# 3. Species-support mask and coding-exon exclusion.
# Use the same merged protein-coding-exon mask for fixed substitutions and the site universe.
awk -F'\t' 'BEGIN{OFS="\t"} $3=="exon" && $9~/transcript_type "protein_coding"/ {print $1,$4-1,$5}' "$GTF" | sort -k1,1 -k2,2n | bedtools merge -i - > "$OUT.protein_coding_exons.bed"
bedtools intersect -sorted -u -a "$OUT.poly.sorted.bed" -b "$SPEC" > "$OUT.poly.support.bed"
bedtools intersect -sorted -u -a "$OUT.fixed.sorted.bed" -b "$SPEC" > "$OUT.fixed.support.before_exon_filter.bed"
bedtools intersect -sorted -v -a "$OUT.fixed.support.before_exon_filter.bed" -b "$OUT.protein_coding_exons.bed" > "$OUT.fixed.support.bed"
printf 'Fixed substitutions after species support, before exon exclusion: '; wc -l < "$OUT.fixed.support.before_exon_filter.bed"
printf 'Fixed substitutions after protein-coding-exon exclusion: '; wc -l < "$OUT.fixed.support.bed"

# Populate new joined-polymorphism file for the common finalization workflow.
bedtools intersect -sorted -wa -wb -a "$OUT.poly.support.bed" -b hg38.panTro6.sort.bed > "$OUT.poly.chimp.tmp.bed"
bedtools intersect -sorted -wa -wb -a "$OUT.poly.chimp.tmp.bed" -b hg38.gorGor6.sort.bed > "$OUT.poly.both.tmp.bed"
BASE="$OUT" OUT="$OUT" bash insight_nc_finish_v2.sh
