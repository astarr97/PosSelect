#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
OUT="${OUT:-INSIGHT_NC_PhyloPgt2_corrected}"
BASE="${BASE:-INSIGHT_NC_PhyloPgt2}"
SPEC="${SPEC:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Recomputing447-way_Final/Scores/All.MskHum.SpecSup.G250.bed}"
PHYLOP="${PHYLOP:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Recomputing447-way_Final/Scores/All.MskHum.PhyloP.bed}"
BETA="${BETA:-beta 0.826972593 0.149422893 0.023604515}"
for f in "$BASE.poly.both.tmp.bed" "$BASE.fixed.support.bed" "$BASE.protein_coding_exons.bed" "$SPEC" "$PHYLOP" hg38.panTro6.sort.bed hg38.gorGor6.sort.bed theta.sorted.bed lambda.sorted.bed make_INSIGHT.py insight_nc_polarize_v2.py; do [[ -s "$f" ]] || { echo "Missing file $f" >&2; exit 1; }; done
# Reuse already generated 19.8 million joined polymorphism records.
python3 insight_nc_polarize_v2.py poly "$BASE.poly.both.tmp.bed" "$OUT.poly.polarized.sorted.bed" "$OUT.poly.polarization_stats.txt"
# Fixed substitutions require ancestral comparisons, which ReadFast lacks; one new streaming scan per outgroup.
# Reuse fixed alignment intersections on rerun if they already exist (set REUSE_FIXED_JOIN=1).
if [[ "${REUSE_FIXED_JOIN:-0}" != 1 ]]; then
  bedtools intersect -sorted -wa -wb -a "$BASE.fixed.support.bed" -b hg38.panTro6.sort.bed > "$OUT.fixed.chimp.tmp.bed"
  bedtools intersect -sorted -wa -wb -a "$OUT.fixed.chimp.tmp.bed" -b hg38.gorGor6.sort.bed > "$OUT.fixed.both.tmp.bed"
fi
[[ -s "$OUT.fixed.both.tmp.bed" ]] || { echo 'Fixed alignment intersection empty' >&2; exit 1; }
python3 insight_nc_polarize_v2.py fixed "$OUT.fixed.both.tmp.bed" "$OUT.fixed.polarized.sorted.bed" "$OUT.fixed.polarization_stats.txt"
# New eligible variant positions may create extra 10kb blocks: regenerate all subsequent stages.
cat "$OUT.poly.polarized.sorted.bed" "$OUT.fixed.polarized.sorted.bed" | cut -f1-3 | sort -k1,1 -k2,2n -u > "$OUT.variant_positions.bed"
bedtools intersect -sorted -wa -wb -a "$OUT.variant_positions.bed" -b theta.sorted.bed > "$OUT.variants.theta.tmp.bed"
bedtools intersect -sorted -wa -wb -a "$OUT.variants.theta.tmp.bed" -b lambda.sorted.bed > "$OUT.variants.theta.lambda.tmp.bed"
awk 'BEGIN{OFS="\t"} $4==$10 && $5==$11 && $6==$12 && $7>0 && $13>0 {print $4,$5,$6}' "$OUT.variants.theta.lambda.tmp.bed" | sort -k1,1 -k2,2n -u > "$OUT.selected_blocks.bed"
[[ -s "$OUT.selected_blocks.bed" ]] || { echo 'No selected neutral blocks' >&2; exit 1; }
bedtools intersect -sorted -wa -wb -a "$OUT.selected_blocks.bed" -b "$PHYLOP" | awk 'BEGIN{OFS="\t"} $7>2 && $5!="." {print $4,$5,$6,$1,$2,$3,$7}' > "$OUT.sites_first.raw.bed"
bedtools intersect -sorted -u -a "$OUT.sites_first.raw.bed" -b "$SPEC" > "$OUT.sites.support.bed"
bedtools intersect -sorted -v -a "$OUT.sites.support.bed" -b "$BASE.protein_coding_exons.bed" > "$OUT.sites.NC.bed"
awk 'BEGIN{OFS="\t"} {print $4,$5,$6,$1,$2,$3,$7,1}' "$OUT.sites.NC.bed" > "$OUT.AllSites.bed"
bedtools intersect -sorted -u -a "$OUT.poly.polarized.sorted.bed" -b "$OUT.sites.NC.bed" > "$OUT.poly.final.bed"
bedtools intersect -sorted -u -a "$OUT.fixed.polarized.sorted.bed" -b "$OUT.sites.NC.bed" > "$OUT.fixed.final.bed"
# Fail loudly when a position is assigned to both variant types.
if [[ $(bedtools intersect -sorted -u -a "$OUT.poly.final.bed" -b "$OUT.fixed.final.bed" | wc -l) -gt 0 ]]; then echo 'ERROR: fixed and poly sites overlap' >&2; exit 1; fi
python3 - "$OUT" <<'PY'
import sys,pathlib
pre=sys.argv[1]
s=pathlib.Path('make_INSIGHT.py').read_text()
replacements={'PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed':pre+'.AllSites.bed','poly.sorted.bed':pre+'.poly.final.bed','fixed.sorted.bed':pre+'.fixed.final.bed','INSIGHT_input.txt':pre+'.input.txt'}
for old,new in replacements.items():
    assert '"'+old+'"' in s, 'Expected filename missing: '+old
    s=s.replace('"'+old+'"','"'+new+'"')
pathlib.Path(pre+'.generator.py').write_text(s)
PY
python3 "$OUT.generator.py"
python3 - "$OUT.input.txt" "$BETA" <<'PY'
import sys,pathlib
p=pathlib.Path(sys.argv[1]);beta=sys.argv[2]
with p.open() as f: head=f.readline()
assert head.startswith('samples ')
tmp=p.with_name(p.name+'.with_beta.tmp')
with p.open() as src,tmp.open('w') as dst:
    first=src.readline();dst.write(first);dst.write(beta+'\n')
    for line in src:
        if line.startswith('beta '):raise ValueError('Duplicate beta')
        dst.write(line)
tmp.replace(p)
PY
printf 'Polymorphism polarization:\n'; cat "$OUT.poly.polarization_stats.txt"
printf 'Fixed polarization:\n'; cat "$OUT.fixed.polarization_stats.txt"
printf 'Final poly/fixed records: '; wc -l "$OUT.poly.final.bed" "$OUT.fixed.final.bed"
awk '$1=="site" {if($3=="L")L++;else if($3=="H")H++;else if($3=="M"&&$4<0.5)D++;else if($3=="M")I++} END {printf "L=%d H=%d D=%d invariant=%d total=%d\n",L,H,D,I,L+H+D+I}' "$OUT.input.txt"
echo "Output: $OUT.input.txt"
