#!/usr/bin/env python3
"""Prepare INSIGHT v1.1 beta-mode input using existing hg38 BEDs.
Requires bedtools and GNU sort in PATH. Run from analysis directory.
Polymorphism BED column 7 is the HUMAN REFERENCE base; column 4 is ALT allele frequency.
The ALT nucleotide itself is absent from this BED, so non-reference ancestral
bases cannot be verified as ALT without the original variant table.
"""
import argparse
import collections
import os
from pathlib import Path
import subprocess
import tempfile

p=argparse.ArgumentParser()
p.add_argument('--poly',default='Polymorphisms_For_INSIGHT_Beta_0.01.bed')
p.add_argument('--neutral',default='INSIGHT_beta_background_sites.bed')
p.add_argument('--chimp',default='hg38.panTro6.sort.bed')
p.add_argument('--gorilla',default='hg38.gorGor6.sort.bed')
p.add_argument('--lambda-bed',default='lambda.sorted.bed')
p.add_argument('--prefix',default='neutral_beta')
p.add_argument('--samples',type=int,default=100000,help='Placeholder for beta mode; main INSIGHT sample size must be corrected separately.')
a=p.parse_args()

def run(command,output):
    with open(output,'w') as o:
        subprocess.run(command,stdout=o,check=True)

def sortbed(path,out):
    run(['sort','-k1,1','-k2,2n',str(path)],out)

def join(path,bfile,out):
    run(['bedtools','intersect','-sorted','-wa','-wb','-a',str(path),'-b',str(bfile)],out)

for f in [a.poly,a.neutral,a.chimp,a.gorilla,a.lambda_bed]:
    if not Path(f).is_file():
        p.error(f'Missing input: {f}')

stats=collections.Counter()
with tempfile.TemporaryDirectory(prefix='insight_beta_',dir='.') as temp:
    t=Path(temp)
    inputs=[a.poly,a.neutral,a.chimp,a.gorilla,a.lambda_bed]
    sorted_inputs=[]
    for i,f in enumerate(inputs):
        if i >= 2:  # chimp/gorilla and lambda are already .sorted.bed files
            sorted_inputs.append(Path(f))
        else:
            dest=t/f'sorted_{i}.bed'
            sortbed(f,dest)
            sorted_inputs.append(dest)
    # 7-column polymorphism + 3-column neutral + 9-column chimp + 9-column gorilla + 5-column lambda
    current=sorted_inputs[0]
    for idx,b in enumerate(sorted_inputs[1:]):
        dest=t/f'join_{idx}.bed'
        join(current,b,dest)
        current=dest
    # Group by block (sort by lambda BED columns, then site columns):
    grouped=t/'grouped.bed'
    run(['sort','-k29,29','-k30,30n','-k1,1','-k2,2n',str(current)],grouped)
    output=Path(a.prefix + '.forBetas.ins')
    audit=Path(a.prefix + '.polarized.tsv')
    prev_site=None
    prev_block=None
    previous_key=None
    with open(grouped) as source, open(output,'w') as ins, open(audit,'w') as aud:
        ins.write(f'samples {a.samples}\n')
        aud.write('chr\tstart\tend\talt_allele_freq\tminor_freq\tref\tchimp\tgorilla\tancestral_class\tpoly_type\tmajor_ancestral_prob\tminor_ancestral_prob\tblock\n')
        for line in source:
            x=line.rstrip('\n').split('\t')
            if len(x)!=33:
                raise ValueError(f'Expected 33 columns, received {len(x)}: {line[:150]}')
            stats['intersected_rows']+=1
            chrom,start,end=x[0],int(x[1]),int(x[2])
            key=(chrom,start,end)
            if key == previous_key:
                stats['duplicate_site_rows']+=1
                continue
            previous_key=key
            refc,chimp=x[13].upper(),x[14].upper()
            refg,gor=x[22].upper(),x[23].upper()
            listed_ref=x[6].upper()
            try: freq=float(x[3])
            except ValueError:
                stats['invalid_frequency']+=1
                continue
            if not (0 < freq < 1):
                stats['invalid_frequency']+=1
                continue
            if not all(z in 'ACGT' and len(z)==1 for z in (refc,chimp,refg,gor,listed_ref)):
                stats['non_acgt']+=1
                continue
            if refc!=refg:
                stats['reference_disagreement']+=1
                continue
            if listed_ref!=refc:
                stats['listed_reference_mismatch']+=1
                continue
            if chimp!=gor:
                stats['outgroup_disagreement']+=1
                continue
            # ALT base is absent: when both outgroups differ from the human REF,
            # assume their shared base is the human ALT (unverifiable here).
            if chimp!=refc:
                stats['ancestral_nonreference_unverified_as_alt']+=1
            maf=min(freq,1-freq)
            cls='L' if maf<0.1 else 'H'
            ancestral_is_ref=(chimp==refc)
            # freq is ALT AF. ALT is minor if freq < 0.5, REF otherwise.
            major_is_ref=(freq<=0.5)
            majprob=0.999 if major_is_ref==ancestral_is_ref else 0.001
            minprob=0.001 if majprob==0.999 else 0.999
            block=(x[28],x[29],x[30])
            if x[28]!=chrom or not (int(x[29]) <=start< int(x[30])):
                stats['bad_lambda_overlap']+=1
                continue
            if cls=='L':
                # Only L sites go into INSIGHT's beta1/beta3 EM.
                if block!=prev_block:
                    ins.write(f'block {block[0]}:{block[1]}-{block[2]} theta 0 lambda {x[31]}\n')
                    prev_block=block
                ins.write(f'site {chrom}:{end} L {majprob:.3f} {minprob:.3f}\n')
            stats['retained_'+cls]+=1
            anc_label='REF' if ancestral_is_ref else 'NONREF_ASSUMED_ALT'
            aud.write(f'{chrom}\t{start}\t{end}\t{freq}\t{maf}\t{refc}\t{chimp}\t{gor}\t{anc_label}\t{cls}\t{majprob}\t{minprob}\t{block[0]}:{block[1]}-{block[2]}\n')
    nL=stats['retained_L']; nH=stats['retained_H']
    if nL+nH:
        beta2=nH/(nL+nH)
        Path(a.prefix+'.beta2.txt').write_text(f'beta2 {beta2:.12g}\nlow {nL}\nhigh {nH}\n')
        print('beta2 (fraction of retained neutral polymorphisms classified H):',beta2)
    else:
        print('WARNING: no usable neutral polymorphisms found')
    print('Stats:')
    for k,v in sorted(stats.items()): print(f'  {k}: {v}')
    print('Outputs:',output,audit,a.prefix+'.beta2.txt')
    print(f'Run: ./bin/INSIGHT-EM-v1.1 -b {output} -v > {a.prefix}.beta_em.log 2>&1')
    print('Then combine beta1/(beta1+beta3) = r from the EM with beta2 = b: beta1=r*(1-b), beta3=(1-r)*(1-b).')
