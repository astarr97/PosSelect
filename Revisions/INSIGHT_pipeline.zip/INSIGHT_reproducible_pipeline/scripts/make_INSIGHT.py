#!/usr/bin/env python3

# Streaming INSIGHT input generator
#
# AllSites format:
#   col1 = block chromosome
#   col2 = block start
#   col3 = block end
#   col4 = site chromosome
#   col5 = site start (0-based)
#   col6 = site end
#   col7 = PhyloP
#
# Poly format:
#   col1 = chr
#   col2 = start (0-based)
#   col6 = MAF
#   col7 = DAF
#
# Fixed format:
#   col1 = chr
#   col2 = start (0-based)
#
# Theta format:
#   col1 = chr
#   col2 = start
#   col3 = end
#   col4 = theta
#
# Lambda format:
#   col1 = chr
#   col2 = start
#   col3 = end
#   col4 = lambda


# -------------------------
# Inputs
# -------------------------

allsites = "PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed"

polyfile = "poly.sorted.bed"

fixedfile = "fixed.sorted.bed"

thetafile = "theta.sorted.bed"

lambda_file = "lambda.sorted.bed"

outfile = "INSIGHT_input.txt"

samples = 100000


# -------------------------
# Load theta/lambda blocks
# -------------------------

print("Loading theta/lambda blocks...")

blocks = {}

print("Loading theta blocks...")

theta_blocks = {}

with open(thetafile) as f:

    for line in f:

        x = line.rstrip().split("\t")

        key = (
            x[0],
            int(x[1]),
            int(x[2])
        )

        theta_blocks[key] = x[3]


print("Theta blocks:", len(theta_blocks))


print("Loading lambda blocks...")

lambda_blocks = {}

with open(lambda_file) as f:

    for line in f:

        x = line.rstrip().split("\t")

        key = (
            x[0],
            int(x[1]),
            int(x[2])
        )

        lambda_blocks[key] = x[3]


print("Lambda blocks:", len(lambda_blocks))

blocks = {}

for key in theta_blocks.keys() & lambda_blocks.keys():

    blocks[key] = {
        "theta": theta_blocks[key],
        "lambda": lambda_blocks[key],
        "blockID": f"{key[0]}:{key[1]}-{key[2]}"
    }


print("Matched blocks:", len(blocks))



# -------------------------
# Streaming polymorphism reader
# -------------------------

def poly_reader(filename):

    with open(filename) as f:

        for line in f:

            x = line.rstrip().split("\t")

            yield {
                "chrom": x[0],
                "pos": int(x[1]) + 1,
                "maf": float(x[5]),
                "daf": float(x[6])
            }



# -------------------------
# Streaming fixed reader
# -------------------------

def fixed_reader(filename):

    with open(filename) as f:

        for line in f:

            x = line.rstrip().split("\t")

            yield {
                "chrom": x[0],
                "pos": int(x[1]) + 1
            }



poly_iter = poly_reader(polyfile)
fixed_iter = fixed_reader(fixedfile)

current_poly = next(poly_iter, None)
current_fixed = next(fixed_iter, None)



# -------------------------
# Advance variant pointers
# -------------------------

def advance_poly(chrom, pos):

    global current_poly

    while current_poly is not None:

        if (
            current_poly["chrom"] < chrom
            or
            (
                current_poly["chrom"] == chrom
                and current_poly["pos"] < pos
            )
        ):

            current_poly = next(poly_iter, None)

        else:

            break



def advance_fixed(chrom, pos):

    global current_fixed

    while current_fixed is not None:

        if (
            current_fixed["chrom"] < chrom
            or
            (
                current_fixed["chrom"] == chrom
                and current_fixed["pos"] < pos
            )
        ):

            current_fixed = next(fixed_iter, None)

        else:

            break



# -------------------------
# Generate INSIGHT input
# -------------------------

print("Generating INSIGHT input...")

with open(outfile, "w") as out:

    out.write(f"samples {samples}\n")

    last_block = None

    with open(allsites) as f:

        for line in f:

            x = line.rstrip().split("\t")


            # -------------------------
            # Extract site information
            # -------------------------

            block_chr = x[0]
            block_start = int(x[1])
            block_end = int(x[2])

            chrom = x[3]
            pos = int(x[4]) + 1

            phyloP = float(x[6])


            # Only high PhyloP sites
            if phyloP <= 2:
                continue



            # -------------------------
            # Get block theta/lambda
            # -------------------------

            block_key = (
                block_chr,
                block_start,
                block_end
            )


            if block_key not in blocks:
                continue


            current_block = blocks[block_key]



            # Write block header once

            if current_block["blockID"] != last_block:

                out.write(
                    f"block {current_block['blockID']} "
                    f"theta {current_block['theta']} "
                    f"lambda {current_block['lambda']}\n"
                )

                last_block = current_block["blockID"]



            # -------------------------
            # Update variant pointers
            # -------------------------
            if chrom == "chr9" and pos == 137245659:
                print("DEBUG")
                print("current_poly:", current_poly)
                print("current_fixed:", current_fixed)
            advance_poly(chrom, pos)

            advance_fixed(chrom, pos)



            # -------------------------
            # Polymorphic site
            # -------------------------

            if (
                current_poly is not None
                and current_poly["chrom"] == chrom
                and current_poly["pos"] == pos
            ):

                if current_poly["maf"] < 0.1:
                    polyType = "L"
                else:
                    polyType = "H"


                # MAF == DAF means minor allele is derived

                if abs(
                    current_poly["maf"]
                    -
                    current_poly["daf"]
                ) < 1e-8:

                    majProb = 0.999
                    minProb = 0.001

                else:

                    majProb = 0.001
                    minProb = 0.999


                out.write(
                    f"site {chrom}:{pos} "
                    f"{polyType} "
                    f"{majProb} "
                    f"{minProb}\n"
                )



            # -------------------------
            # Fixed substitution
            # -------------------------

            elif (
                current_fixed is not None
                and current_fixed["chrom"] == chrom
                and current_fixed["pos"] == pos
            ):

                out.write(
                    f"site {chrom}:{pos} M 0.001\n"
                )



            # -------------------------
            # Monomorphic non-divergent
            # -------------------------

            else:

                out.write(
                    f"site {chrom}:{pos} M 0.999\n"
                )



print("Finished generating:", outfile)
