# INSIGHT selection analyses — reconstructed reproducible pipeline

**Scope.** This package consolidates the actual Python/shell scripts recovered from the analysis, including noncoding, conserved coding, haploinsufficient-gene, 15% MAF sensitivity, neutral-beta, and nearest-promoter workflows. The original scripts are in `scripts/` (with historical exploratory variants in `legacy/`); `run_pipeline.py` provides memorable stage names. It is a reconstruction of the workflow, **not a claim that every upstream data-preparation command was recovered**.

## Requirements

- Stanford HPC Linux environment, `python3` (the nearest-promoter script uses `universal_newlines=True`, compatible with Python 3.6), `bedtools`, GNU `sort`, `awk`, SLURM as desired.
- INSIGHT-EM v1.1 executable `bin/INSIGHT-EM-v1.1` (not redistributed).
- GRCh38 GENCODE GTF, genome-wide masked-human PhyloP BED, SpecSup G250 BED, downloaded INSIGHT 10-kb neutral theta/lambda tracks lifted hg19→GRCh38.
- Human–chimp/gorilla alignment BEDs `hg38.panTro6.sort.bed` / `hg38.gorGor6.sort.bed`, produced from UCSC pairwise MAFs using `callSNPsFromMAF.py`. These are **huge** (one approximately 127 GB); the restart stage reuses `INSIGHT_NC_PhyloPgt2.poly.both.tmp.bed`.
- User-provided input catalogs: nonsynonymous `PhyloPG2_Nonsyn_ForINSIGHT_Poly.bed` and `PhyloPG2_Nonsyn_ForINSIGHT_Fixed.bed` (or their prepared `poly.sorted.bed` / `fixed.sorted.bed`), noncoding polymorphism input `HumanPoly_MAF0.001_AF_Cons_VEP_ChpGorFilt.txt`, and fixed noncoding `HumChp_NC_Final_NoHLA_ReadFast.txt`.
- Main genomic files remain **outside** this archive due to size / licensing. Paths in `scripts/build_insight_nc_corrected.sh` and related files are the historical cluster defaults; edit/env-override as necessary.

## Quick start (run in existing analysis directory)

```bash
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py check --workdir /absolute/path/to/INSIGHT
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py noncoding-resume --workdir /absolute/path/to/INSIGHT
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py noncoding-fit --workdir /absolute/path/to/INSIGHT
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py gene-panel --workdir /absolute/path/to/INSIGHT
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py gene-panel-fit --workdir /absolute/path/to/INSIGHT
```

For fresh noncoding preprocessing instead of restart:

```bash
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py noncoding-full --workdir /absolute/path/to/INSIGHT
```

For conserved CDS / HI-gene analyses, **starting from the original coding variant joins and AllSites**:

```bash
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py coding-prepare --workdir /absolute/path/to/INSIGHT
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py coding-fit --workdir /absolute/path/to/INSIGHT
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py coding-hi --workdir /absolute/path/to/INSIGHT
```

Then fit the HI input manually: `./bin/INSIGHT-EM-v1.1 INSIGHT_HI_CDS_PhyloPgt2.input.txt -v > INSIGHT_HI_CDS_PhyloPgt2.log 2>&1`.

For re-estimating beta from the previously prepared neutral background (expensive):

```bash
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py beta-prep --workdir /absolute/path/to/INSIGHT
python3 /path/to/INSIGHT_reproducible_pipeline/run_pipeline.py beta-fit --workdir /absolute/path/to/INSIGHT
```

**Important:** the beta fit writes the EM output. The `beta` line used historically was `beta 0.826972593 0.149422893 0.023604515`, derived by combining the beta EM result and the observed high-frequency neutral fraction; `beta-prep` / `beta-fit` do not automatically propagate newly estimated beta parameters into the analysis. The previously used beta results should be documented and compared before changing them.

To reproduce the 15% cutoff sensitivity for **coding** data, run stage `sensitivity-15`, which re-estimates beta, relabels L/H, and fits the old coding inputs. This is not a generic noncoding 15% routine.

## Analysis stages and filenames

| Stage | Input | Output |
| --- | --- | --- |
| Coding variants | upstream nonsynonymous variant catalogs + lifted neutral parameters | `poly.sorted.bed`, `fixed.sorted.bed`, `PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed` (historical preparation in `legacy/commands.sh`) |
| Coding CDS mask | AllSites + protein-coding CDS from GTF | `INSIGHT_CDS_PhyloPgt2_input.txt` |
| Coding HI subset | same AllSites + GTF + `NonsynDep2_HI_Genes.txt` | `INSIGHT_HI_CDS_PhyloPgt2.input.txt` |
| Noncoding variants | variant input tables + G250 + GTF | `.poly.support.bed`, `.fixed.support.bed`, `.poly.both.tmp.bed` |
| Noncoding polarization | 7+9+9 polymorphism join; 5+9+9 fixed join | `.poly.polarized.sorted.bed`, `.fixed.polarized.sorted.bed` |
| Noncoding finalization | selected theta/lambda blocks + PhyloP > 2 + G250 + coding exon mask | `INSIGHT_NC_PhyloPgt2_corrected.input.txt` |
| Gene panel | corrected INSIGHT input + all promoter annotations | `.nearest_gene_panel.input.txt` |

### Noncoding filtering details

- Polymorphisms: VEP consequence and biotype lists are paired, excluding `missense_variant`, `5_prime_UTR_variant`, `3_prime_UTR_variant` on protein-coding transcripts; maximum ALT AF across eight population columns, MAF = `min(AF,1-AF)` ≥ 0.001. **The VEP parser excluded ~1.79M rows with mismatched lists; verify input format before using as definitive methodology.**
- Fixed ReadFast input: PhyloP > 2, SpecSup > 250, exclusion of protein-coding transcript exons. Polymorphisms receive the same exon-site mask at the final sites stage.
- Polarization: no strand complementation: the `callSNPsFromMAF.py` output bases are already in alignment-column orientation. For polymorphisms require chimp/gorilla agreement and ancestral call matching REF or ALT; keep the **highest-MAF** eligible allele at multiallelic sites. For ReadFast fixed substitutions, require **only chimp/gorilla agreement**, without requiring human/outgroup nucleotide differences.
- Neutral blocks: require exact theta/lambda interval matches, with theta > 0 and lambda > 0. X chromosome is effectively absent because the downloaded theta track has zero estimates on chrX.
- Selected site universe: within eligible blocks, PhyloP > 2, SpecSup > 250, outside coding transcript exons. INSIGHT records L for MAF < 0.10 and H for MAF ≥ 0.10; beta line from historical calibration.
- The promoter-subset workflow assigns each eligible position to the closest promoter **among all genes**, and only then keeps positions whose nearest gene is in the 48-gene panel.

## Existing analysis results for sanity checks (not re-estimates)

- Corrected noncoding: `L=800012; H=121342; D=235444; invariant=91482829; total=92639627`; `poly.final` 921,354 rows, `fixed.final` 235,444 rows.
- Corrected noncoding polarization: 19,708,654 polymorphism positions seen; 18,867,541 retained; 98,999 multiallelic positions; 269,663 fixed positions seen and retained prior to neutral-block exclusion.
- Original coding CDS INSIGHT fit: 7,070,439 sites; alpha 0.000000. Original HI subset: 1,128,224 sites; alpha 0.000000. The original coding 15% threshold run also gave alpha 0, but high uncertainty.

## Known uncertainties / validation checklist

1. **Upstream nonsynonymous ascertainment**: the exact generation of `PhyloPG2_Nonsyn_ForINSIGHT_*` BEDs is not available. Existing historical BEDs are required inputs.
2. **Coding universe mismatch**: coding input counts all PhyloP > 2 CDS bases, but only nonsynonymous polymorphic and fixed events; synonymous variation is omitted. This may affect INSIGHT's inference.
3. **Neutral beta polarization**: the original `Polymorphisms_For_INSIGHT_Beta_0.01.bed` lacks ALT nucleotide, so the beta estimator assumes a non-REF concordant chimp/gorilla allele is the ALT. It could not verify those cases independently. Beta was estimated using non-exonic low-PhyloP sites in selected blocks and transferred to subsequent analyses.
4. **`samples 100000`**: historical approximation, not verified as the actual chromosome count for every sample/population and particularly unsuitable to chrX.
5. **Noncoding VEP parsing**: splitting whitespace may shift empty annotation columns. Large rejected mismatch count requires a spot-check or more robust source parser before publication-grade reproducibility.
6. **Fixed filtering**: all 269,663 pre-block fixed positions passed the reconstructed outgroup-consensus step; likely expected due to prior ReadFast filtering, but worth independently validating a sample.
7. **Neutral-track coverage**: 34,219 of 269,663 original fixed sites did not overlap positive, matching theta/lambda blocks: 25,258 missing at least one track and 8,961 with both covered but no valid matched positive block (several had theta=0).
8. **Coordinate-sorted files**: `bedtools intersect -sorted` requires compatible chromosome ordering (the historic scripts use `LC_ALL=C sort -k1,1 -k2,2n`). Verify source tracks are compatible before launching a full run.
9. **Earlier coding 15% test**: `run_insight_15pct.py` was built for preexisting CDS/HI files and requires the original beta infrastructure. Its thresholds are not automatically propagated to the corrected noncoding pipeline.
10. **Source consistency**: The files here are recovered scripts, not an exact clean-room rebuild. Test one chromosome/small region before reusing on new data. The complete noncoding stage may need the additional large source tracks and is much more expensive than restarting.

## Archive structure

- `run_pipeline.py` — simple, explicit dispatcher with dependency checks.
- `scripts/` — recovered functional source scripts, plus `prepare_coding_cds.sh` reconstructed from the documented CDS workflow.
- `legacy/` — predecessor/experimental scripts preserved for provenance, not recommended as primary entry points.
- `config/NonsynDep2_HI_Genes.txt` — user-provided original HI gene list; copy into the working directory for the HI stage.

This package does not distribute INSIGHT-EM itself, genome-wide scores, genome alignments, or original private/large intermediate files.
