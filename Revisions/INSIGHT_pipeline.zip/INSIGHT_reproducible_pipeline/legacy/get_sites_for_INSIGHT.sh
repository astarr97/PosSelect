awk '
{
    max = $6
    for (i=7; i<=12; i++) {
        if ($i > max) max = $i
    }

    if (max > 0.001 && max < 0.1) {
        split($1, a, "[:-]")
        print a[1] "\t" (a[2]-1) "\t" a[3] "\t" max "\tL\t" (a[3]) "\t" (a[4])
    }
    else if (max >= 0.1) {
        split($1, a, "[:-]")
        print a[1] "\t" (a[2]-1) "\t" a[3] "\t" max "\tH\t" (a[3]) "\t" (a[4])
    }
}' OFS="\t" /oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Final_Files_PosSelect/HumanPoly_MAF0.001_AF_Cons_VEP_ChpGorFilt.txt > Polymorphisms_For_INSIGHT_Beta_0.01.bed
