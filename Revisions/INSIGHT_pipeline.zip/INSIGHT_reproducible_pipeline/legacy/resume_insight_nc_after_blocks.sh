#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
OUT="${OUT:-INSIGHT_NC_PhyloPgt2}"
SPEC="${SPEC:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Recomputing447-way_Final/Scores/All.MskHum.SpecSup.G250.bed}"
PHYLOP="${PHYLOP:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Recomputing447-way_Final/Scores/All.MskHum.PhyloP.bed}"
BETA="${BETA:-beta 0.826972593 0.149422893 0.023604515}"
for f in "$OUT.selected_blocks.bed" "$OUT.protein_coding_exons.bed" "$OUT.poly.polarized.sorted.bed" "$OUT.fixed.support.bed" "$OUT.parse_stats.txt" "$OUT.polarization_stats.txt" "$SPEC" "$PHYLOP" theta.sorted.bed lambda.sorted.bed make_INSIGHT.py; do
  [[ -s "$f" ]] || { echo "ERROR: Missing or empty prerequisite $f" >&2; exit 1; }
done
command -v bedtools >/dev/null || { echo 'ERROR: bedtools not found' >&2; exit 1; }
echo "Resuming from $OUT.selected_blocks.bed ($(wc -l < "$OUT.selected_blocks.bed") intervals)"
# 6. Build universe of PhyloP>2 nucleotides in these blocks, preserve original AllSites column layout.
bedtools intersect -sorted -wa -wb -a "$OUT.selected_blocks.bed" -b "$PHYLOP" | awk 'BEGIN{OFS="\t"} $7>2 && $5!="." {print $4,$5,$6,$1,$2,$3,$7}' > "$OUT.sites_first.raw.bed"
# Sites in spec-support mask, then remove all exons of protein-coding transcripts (CDS and UTR).
bedtools intersect -sorted -u -a "$OUT.sites_first.raw.bed" -b "$SPEC" > "$OUT.sites.support.bed"
bedtools intersect -sorted -v -a "$OUT.sites.support.bed" -b "$OUT.protein_coding_exons.bed" > "$OUT.sites.NC.bed"
awk 'BEGIN{OFS="\t"} {print $4,$5,$6,$1,$2,$3,$7,1}' "$OUT.sites.NC.bed" > "$OUT.AllSites.bed"

# 7. Eliminate variant records outside the exact tested positions, then generate INSIGHT input.
bedtools intersect -sorted -u -a "$OUT.poly.polarized.sorted.bed" -b "$OUT.sites.NC.bed" > "$OUT.poly.final.bed"
bedtools intersect -sorted -u -a "$OUT.fixed.support.bed" -b "$OUT.sites.NC.bed" > "$OUT.fixed.final.bed"
# Adapt the existing generator without changing it; substitute ALL five expected filenames.
python3 - "$OUT" <<'PY'
import sys,pathlib
prefix=sys.argv[1]
p=pathlib.Path('make_INSIGHT.py')
if not p.exists(): raise SystemExit('ERROR: make_INSIGHT.py missing')
s=p.read_text()
replacements={
    'PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed':prefix+'.AllSites.bed',
    'poly.sorted.bed':prefix+'.poly.final.bed',
    'fixed.sorted.bed':prefix+'.fixed.final.bed',
    'INSIGHT_input.txt':prefix+'.input.txt',
}
for old,new in replacements.items():
    if f'"{old}"' not in s: raise SystemExit('ERROR: Expected literal not found: '+old)
    s=s.replace(f'"{old}"',f'"{new}"')
pathlib.Path(prefix+'.generator.py').write_text(s)
PY
python3 "$OUT.generator.py"
# Add beta exactly once.
python3 - "$OUT.input.txt" "$BETA" <<'PY'
import sys,pathlib
p=pathlib.Path(sys.argv[1]); beta=sys.argv[2]
with p.open() as f: lines=f.readlines()
assert lines and lines[0].startswith('samples '), 'Missing samples line'
assert not any(x.startswith('beta ') for x in lines), 'Already has beta line'
with p.open('w') as f: f.write(lines[0]);f.write(beta+'\n');f.writelines(lines[1:])
PY

echo '--- Parsing statistics ---'; cat "$OUT.parse_stats.txt" "$OUT.polarization_stats.txt"
echo '--- INSIGHT site-class counts ---'
awk '$1=="site" {if($3=="L")L++;else if($3=="H")H++;else if($3=="M"&&$4<0.5)D++;else if($3=="M")I++} END {printf "L=%d H=%d D=%d invariant=%d total=%d\n",L,H,D,I,L+H+D+I}' "$OUT.input.txt"
echo '--- Block count ---'; grep -c '^block ' "$OUT.input.txt" || true
printf 'Output: %s.input.txt\n' "$OUT"
