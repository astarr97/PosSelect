
#Downloaded the 10k lambda/theta files with "-no" from here http://compgen.cshl.edu/INSIGHT/downloads/INSIGHTpackage/preprocessedHumanData/forTFBS/
#Lifted over from hg19 to hg38

#bedtools intersect -wao -a PhyloPG2_Nonsyn_ForINSIGHT_Poly.bed -b theta-10K_hg38.bed > PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta.bed
#bedtools intersect -wao -a PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta.bed -b lambda-10K_hg38.bed > PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda.bed

#bedtools intersect -wao -a PhyloPG2_Nonsyn_ForINSIGHT_Fixed.bed -b theta-10K_hg38.bed > PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta.bed
#bedtools intersect -wao -a PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta.bed -b lambda-10K_hg38.bed > PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta_Lambda.bed

#awk -F'\t' 'BEGIN{OFS="\t"} $9 != 0 && $16 != 0 && $9 != "." && $16 != "." {print $1,$2,$3,$4,$5,$9,$16}' PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta_Lambda.bed > PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta_Lambda_cols9_16.bed
#awk -F'\t' 'BEGIN{OFS="\t"} $9 != 0 && $16 != 0 && $9 != "." && $16 != "." {print $6,$7,$8}' PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta_Lambda.bed > PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta_Lambda_cols6_8.bed
#awk -F'\t' 'BEGIN{OFS="\t"} $11 != 0 && $18 != 0 && $11 != "." && $18 != "." {print $1,$2,$3,$4,$5,$6,$7,$11,$18}' PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda.bed > PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_cols9_16.bed
#awk -F'\t' 'BEGIN{OFS="\t"} $11 != 0 && $18 != 0 && $11 != "." && $18 != "." {print $8,$9,$10}' PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda.bed > PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_cols6_8.bed

#sort -u PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_cols6_8.bed | sort -k1,1 -k2,2n > PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_cols6_8_uniq.bed
#sort -u PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta_Lambda_cols6_8.bed | sort -k1,1 -k2,2n > PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta_Lambda_cols6_8_uniq.bed

#cat PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_cols6_8_uniq.bed PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta_Lambda_cols6_8_uniq.bed | sort -u | sort -k1,1 -k2,2n > PhyloPG2_Nonsyn_ForINSIGHT_FixedPoly_Theta_Lambda.bed
#bedtools intersect -sorted -wao -a PhyloPG2_Nonsyn_ForINSIGHT_FixedPoly_Theta_Lambda.bed -b /oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Recomputing447-way_Final/Scores/All.MskHum.PhyloP.bed > PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed

sort -k1,1 -k2,2n lambda-10K_hg38.bed > lambda.sorted.bed
sort -k1,1 -k2,2n theta-10K_hg38.bed > theta.sorted.bed

sort -k1,1 -k2,2n PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_cols9_16.bed > poly.sorted.bed
sort -k1,1 -k2,2n PhyloPG2_Nonsyn_ForINSIGHT_Fixed_Theta_Lambda_cols9_16.bed > fixed.sorted.bed

python make_INSIGHT.py

#Filtering to try to estimate their beta
awk -F'\t' 'BEGIN{OFS="\t"} $3=="exon" { print $1,$4-1,$5 }' /oak/stanford/groups/hbfraser/astarr/human.gtf | sort -k1,1 -k2,2n > gencode_exons.bed
awk -F'\t' 'BEGIN{OFS="\t"} $7 > -2 && $7 < 0.5 { print $4,$5,$6}' PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed > AllSites_PhyloP_neutral_candidate.bed
bedtools intersect -v -a AllSites_PhyloP_neutral_candidate.bed -b gencode_exons.bed > INSIGHT_beta_background_sites.bed

#Get the beta polymorphisms
#NEED TO ADD THE HUMAN/CHIMP/GORILLA BASE
./get_sites_for_INSIGHT.sh

./bin/INSIGHT-EM-v1.1 INSIGHT_input.txt
