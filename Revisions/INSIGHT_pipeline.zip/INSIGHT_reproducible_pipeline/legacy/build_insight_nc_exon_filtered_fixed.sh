#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

# Run from original INSIGHT directory; override these environment variables as needed.
POLY_SRC="${POLY_SRC:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Final_Files_PosSelect/HumanPoly_MAF0.001_AF_Cons_VEP_ChpGorFilt.txt}"
FIXED_SRC="${FIXED_SRC:-HumChp_NC_Final_NoHLA_ReadFast.txt}"
SPEC="${SPEC:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Recomputing447-way_Final/Scores/All.MskHum.SpecSup.G250.bed}"
PHYLOP="${PHYLOP:-/oak/stanford/groups/hbfraser/astarr/PosSelect_AccelEvol/Recomputing447-way_Final/Scores/All.MskHum.PhyloP.bed}"
GTF="${GTF:-/oak/stanford/groups/hbfraser/astarr/human.gtf}"
OUT="${OUT:-INSIGHT_NC_PhyloPgt2}"
BETA="${BETA:-beta 0.826972593 0.149422893 0.023604515}"

for f in "$POLY_SRC" "$FIXED_SRC" "$SPEC" "$PHYLOP" "$GTF" theta.sorted.bed lambda.sorted.bed hg38.panTro6.sort.bed hg38.gorGor6.sort.bed; do [[ -s "$f" ]] || { echo "ERROR: missing/empty $f" >&2; exit 1; }; done
command -v bedtools >/dev/null

# 1. Parse tab-or-space-delimited human variant table. VEP consequence and biotype lists are paired by index.
python3 - "$POLY_SRC" "$OUT.poly.raw.bed" "$OUT.parse_stats.txt" <<'PY'
import sys,re,collections,math
src,dst,report=sys.argv[1:]
st=collections.Counter()
with open(src) as inp, open(dst,'w') as out:
    for line in inp:
        if not line.strip() or line.startswith('#'): continue
        a=line.split()
        st['source_rows']+=1
        if len(a)<24: st['short_rows']+=1; continue
        m=re.fullmatch(r'(chr[^:]+):(\d+)-(\d+)-([ACGT]+)-([ACGT]+)',a[0])
        if not m or len(m[4])!=1 or len(m[5])!=1 or m[2]!=m[3]: st['non_snv_or_bad_id']+=1; continue
        chrom,pos_s,_,ref,alt=m.groups(); pos=int(pos_s)
        if a[2].upper()!=ref or a[3].upper()!=alt: st['ref_alt_mismatch']+=1; continue
        consequences=a[21].strip(';').split(';')
        biotypes=a[23].strip(';').split(';')
        if len(consequences)!=len(biotypes): st['vep_pair_count_mismatch']+=1; continue
        excluded=False
        for c,b in zip(consequences,biotypes):
            effects=c.split('&')
            if b=='protein_coding' and any(x in ('missense_variant','5_prime_UTR_variant','3_prime_UTR_variant') for x in effects):
                excluded=True; break
        if excluded: st['excluded_protein_coding_missense_or_UTR']+=1; continue
        try: freqs=[float(v) for v in a[4:12]]
        except ValueError: st['bad_frequency']+=1; continue
        if not all(math.isfinite(f) and 0<=f<=1 for f in freqs): st['bad_frequency']+=1; continue
        af=max(freqs)
        maf=min(af,1-af)
        if maf<0.001: st['maf_below_0.001']+=1; continue
        # BED chrom, start, end, ALT frequency, human ref, human alt, max-population MAF.
        out.write(f'{chrom}\t{pos-1}\t{pos}\t{af:.12g}\t{ref}\t{alt}\t{maf:.12g}\n')
        st['passed_VEP_and_MAF']+=1
with open(report,'w') as out:
    for k,v in sorted(st.items()): out.write(f'{k}\t{v}\n')
PY
sort -k1,1 -k2,2n "$OUT.poly.raw.bed" > "$OUT.poly.sorted.bed"

# 2. Convert fixed NC human-derived changes to zero-based BED; require high PhyloP at the variant itself.
python3 - "$FIXED_SRC" "$OUT.fixed.raw.bed" <<'PY'
import sys,re
with open(sys.argv[1]) as inp,open(sys.argv[2],'w') as out:
    for line in inp:
        a=line.split()
        if len(a)<6 or a[0]=='Position': continue
        m=re.fullmatch(r'(chr[^:]+):(\d+)',a[0])
        if not m: continue
        try: pp=float(a[3]); support=float(a[5])
        except ValueError: continue
        if pp>2 and support>250:
            chrom,pos=m[1],int(m[2]); out.write(f'{chrom}\t{pos-1}\t{pos}\t{pp:.12g}\t{a[1]}\n')
PY
sort -k1,1 -k2,2n "$OUT.fixed.raw.bed" > "$OUT.fixed.sorted.bed"

# 3. Species-support mask and coding-exon exclusion.
# Use the same merged protein-coding-exon mask for fixed substitutions and the site universe.
awk -F'\t' 'BEGIN{OFS="\t"} $3=="exon" && $9~/transcript_type "protein_coding"/ {print $1,$4-1,$5}' "$GTF" | sort -k1,1 -k2,2n | bedtools merge -i - > "$OUT.protein_coding_exons.bed"
bedtools intersect -sorted -u -a "$OUT.poly.sorted.bed" -b "$SPEC" > "$OUT.poly.support.bed"
bedtools intersect -sorted -u -a "$OUT.fixed.sorted.bed" -b "$SPEC" > "$OUT.fixed.support.before_exon_filter.bed"
bedtools intersect -sorted -v -a "$OUT.fixed.support.before_exon_filter.bed" -b "$OUT.protein_coding_exons.bed" > "$OUT.fixed.support.bed"
printf 'Fixed substitutions after species support, before exon exclusion: '; wc -l < "$OUT.fixed.support.before_exon_filter.bed"
printf 'Fixed substitutions after protein-coding-exon exclusion: '; wc -l < "$OUT.fixed.support.bed"

# 4. Polarize polymorphisms with chimp + gorilla consensus; transform into make_INSIGHT.py's format.
# Two -wa -wb intersections use existing pre-sorted whole-genome base tables; no re-sorting of alignments.
bedtools intersect -sorted -wa -wb -a "$OUT.poly.support.bed" -b hg38.panTro6.sort.bed > "$OUT.poly.chimp.tmp.bed"
bedtools intersect -sorted -wa -wb -a "$OUT.poly.chimp.tmp.bed" -b hg38.gorGor6.sort.bed > "$OUT.poly.both.tmp.bed"
python3 - "$OUT.poly.both.tmp.bed" "$OUT.poly.polarized.raw.bed" "$OUT.polarization_stats.txt" <<'PY'
import sys,collections
src,dst,rep=sys.argv[1:]; c=collections.Counter(); seen=set()
comp=str.maketrans('ACGT','TGCA')
with open(src) as inp,open(dst,'w') as out:
    for line in inp:
        a=line.split('\t'); c['aligned_rows']+=1
        # 7 human columns; 9 chimp; 9 gorilla.
        if len(a)<25: c['invalid_row']+=1; continue
        chrom,start,end,af,ref,alt,maf=a[:7]
        pos=(chrom,start)
        if pos in seen: c['duplicate_alignment_or_variant']+=1; continue
        # Reject ambiguous mapped bases, reference base disagreement and negative-strand outgroup unless validated.
        def ancestral(z):
            human_base=z[3].upper(); outgroup_base=z[4].upper()
            if z[5]!=z[6]: outgroup_base=outgroup_base.translate(comp)
            return human_base,outgroup_base
        ch=a[7:16]; go=a[16:25]
        hc,anc1=ancestral(ch); hg,anc2=ancestral(go)
        if hc!=ref or hg!=ref or anc1 not in 'ACGT' or anc2 not in 'ACGT': c['alignment_ref_or_base_invalid']+=1; continue
        if anc1!=anc2: c['chimp_gorilla_disagree']+=1; continue
        if anc1 not in (ref,alt): c['ancestral_not_ref_or_alt']+=1; continue
        daf=float(af) if anc1==ref else 1-float(af)
        # col 6 MAF, col 7 DAF in make_INSIGHT.py
        out.write(f'{chrom}\t{start}\t{end}\t0\tNC\t{maf}\t{daf:.12g}\n')
        seen.add(pos); c['retained_polarized']+=1
with open(rep,'w') as out:
    for k,v in sorted(c.items()): out.write(f'{k}\t{v}\n')
PY
sort -k1,1 -k2,2n "$OUT.poly.polarized.raw.bed" > "$OUT.poly.polarized.sorted.bed"

# 5. Select neutral theta/lambda blocks containing eligible observed variants; require matching block coordinates and positive rates.
cat "$OUT.poly.polarized.sorted.bed" "$OUT.fixed.support.bed" | cut -f1-3 | sort -k1,1 -k2,2n -u > "$OUT.variant_positions.bed"
bedtools intersect -sorted -wa -wb -a "$OUT.variant_positions.bed" -b theta.sorted.bed > "$OUT.variants.theta.tmp.bed"
bedtools intersect -sorted -wa -wb -a "$OUT.variants.theta.tmp.bed" -b lambda.sorted.bed > "$OUT.variants.theta.lambda.tmp.bed"
awk 'BEGIN{OFS="\t"} $4==$10 && $5==$11 && $6==$12 && $7>0 && $13>0 {print $4,$5,$6}' "$OUT.variants.theta.lambda.tmp.bed" | sort -k1,1 -k2,2n -u > "$OUT.selected_blocks.bed"
[[ -s "$OUT.selected_blocks.bed" ]] || { echo 'ERROR: No valid selected blocks' >&2; exit 1; }

# 6. Build universe of PhyloP>2 nucleotides in these blocks, preserve original AllSites column layout.
bedtools intersect -sorted -wa -wb -a "$OUT.selected_blocks.bed" -b "$PHYLOP" | awk 'BEGIN{OFS="\t"} $7>2 && $5!="." {print $4,$5,$6,$1,$2,$3,$7}' > "$OUT.sites_first.raw.bed"
# Sites in spec-support mask, then remove all exons of protein-coding transcripts (CDS and UTR).
bedtools intersect -sorted -u -a "$OUT.sites_first.raw.bed" -b "$SPEC" > "$OUT.sites.support.bed"
bedtools intersect -sorted -v -a "$OUT.sites.support.bed" -b "$OUT.protein_coding_exons.bed" > "$OUT.sites.NC.bed"
awk 'BEGIN{OFS="\t"} {print $4,$5,$6,$1,$2,$3,$7,1}' "$OUT.sites.NC.bed" > "$OUT.AllSites.bed"

# 7. Eliminate variant records outside the exact tested positions, then generate INSIGHT input.
bedtools intersect -sorted -u -a "$OUT.poly.polarized.sorted.bed" -b "$OUT.sites.NC.bed" > "$OUT.poly.final.bed"
bedtools intersect -sorted -u -a "$OUT.fixed.support.bed" -b "$OUT.sites.NC.bed" > "$OUT.fixed.final.bed"
# Adapt the existing generator without changing it; substitute ALL five expected filenames.
python3 - "$OUT" <<'PY'
import sys,pathlib
prefix=sys.argv[1]
p=pathlib.Path('make_INSIGHT.py')
if not p.exists(): raise SystemExit('ERROR: make_INSIGHT.py missing')
s=p.read_text()
replacements={
    'PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed':prefix+'.AllSites.bed',
    'poly.sorted.bed':prefix+'.poly.final.bed',
    'fixed.sorted.bed':prefix+'.fixed.final.bed',
    'INSIGHT_input.txt':prefix+'.input.txt',
}
for old,new in replacements.items():
    if f'"{old}"' not in s: raise SystemExit('ERROR: Expected literal not found: '+old)
    s=s.replace(f'"{old}"',f'"{new}"')
pathlib.Path(prefix+'.generator.py').write_text(s)
PY
python3 "$OUT.generator.py"
# Add beta exactly once.
python3 - "$OUT.input.txt" "$BETA" <<'PY'
import sys,pathlib
p=pathlib.Path(sys.argv[1]); beta=sys.argv[2]
with p.open() as f: lines=f.readlines()
assert lines and lines[0].startswith('samples '), 'Missing samples line'
assert not any(x.startswith('beta ') for x in lines), 'Already has beta line'
with p.open('w') as f: f.write(lines[0]);f.write(beta+'\n');f.writelines(lines[1:])
PY

echo '--- Parsing statistics ---'; cat "$OUT.parse_stats.txt" "$OUT.polarization_stats.txt"
echo '--- INSIGHT site-class counts ---'
awk '$1=="site" {if($3=="L")L++;else if($3=="H")H++;else if($3=="M"&&$4<0.5)D++;else if($3=="M")I++} END {printf "L=%d H=%d D=%d invariant=%d total=%d\n",L,H,D,I,L+H+D+I}' "$OUT.input.txt"
echo '--- Block count ---'; grep -c '^block ' "$OUT.input.txt" || true
printf 'Output: %s.input.txt\n' "$OUT"
