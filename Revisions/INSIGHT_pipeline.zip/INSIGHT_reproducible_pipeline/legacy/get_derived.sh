#!/bin/bash
#SBATCH --time=168:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=32G

#Chimp using UCSC version and hg38/PanTro6
#wget -P chimp ftp://hgdownload.soe.ucsc.edu/goldenPath/hg38/vsPanTro6/hg38.panTro6.synNet.maf.gz
gunzip chimp/hg38.panTro6.synNet.maf.gz
#Gorilla using hg38/gorgor6
#wget -P gorilla ftp://hgdownload.soe.ucsc.edu/goldenPath/hg38/vsGorGor6/hg38.gorGor6.synNet.maf.gz
#gunzip hg38.gorGor6.synNet.maf.gz

python callSNPsFromMAF.py chimp/hg38.panTro6.synNet.maf hg38.panTro6.bed
python callSNPsFromMAF.py gorilla/hg38.gorGor6.synNet.maf hg38.gorGor6.bed

sort -k1,1 -k2,2n hg38.panTro6.bed > hg38.panTro6.sort.bed
sort -k1,1 -k2,2n hg38.gorGor6.bed > hg38.gorGor6.sort.bed
