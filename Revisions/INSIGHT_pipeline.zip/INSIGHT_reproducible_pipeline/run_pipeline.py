#!/usr/bin/env python3
"""Entrypoint for the reconstructed INSIGHT analysis; run inside the analysis work directory.

The scripts/ are the recovered scientific implementation. This runner copies those
scripts locally (where their historic filenames and relative paths work) and offers
well-defined stages. It never silently downloads/rebuilds gigantic reference tracks.
"""
import argparse, pathlib, shutil, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parent
SCRIPTS = ROOT / 'scripts'
NAMES = [p.name for p in SCRIPTS.iterdir() if p.is_file()]
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('stage',choices=['install','noncoding-full','noncoding-resume','noncoding-fit','coding-prepare','coding-hi','coding-fit','beta-prep','beta-fit','sensitivity-15','gene-panel','gene-panel-fit','check'])
p.add_argument('--workdir',default='.',help='Analysis directory containing prepared reference tracks and inputs')
p.add_argument('--force-install',action='store_true',help='Overwrite already present scripts with packaged versions')
p.add_argument('--samples',type=int,default=100000)
a=p.parse_args()
w=pathlib.Path(a.workdir).resolve()
w.mkdir(parents=True,exist_ok=True)
def install():
  for n in NAMES:
    dst=w/n
    if a.force_install or not dst.exists():
      shutil.copy2(SCRIPTS/n,dst)
  genes=ROOT/'config'/'NonsynDep2_HI_Genes.txt'
  if genes.is_file() and (a.force_install or not (w/genes.name).exists()):
    shutil.copy2(genes,w/genes.name)
  print('Installed pipeline helpers into',w)
def need(*names):
  missing=[str(w/n) for n in names if not (w/n).is_file()]
  if missing: p.error('Missing required files:\n  '+'\n  '.join(missing))
def run(*cmd, logfile=None):
  print('Running:', ' '.join(map(str,cmd)),flush=True)
  if logfile:
    with open(w/logfile,'w') as o: subprocess.run(list(map(str,cmd)),cwd=str(w),stdout=o,stderr=subprocess.STDOUT,check=True)
  else: subprocess.run(list(map(str,cmd)),cwd=str(w),check=True)
def fit(inp,log):
  need('bin/INSIGHT-EM-v1.1',inp)
  run('./bin/INSIGHT-EM-v1.1',inp,'-v',logfile=log)
if a.stage=='install': install(); sys.exit(0)
install()
if a.stage=='noncoding-full': run('bash','build_insight_nc_corrected.sh')
elif a.stage=='noncoding-resume': run('bash','resume_insight_nc_corrected.sh')
elif a.stage=='noncoding-fit': fit('INSIGHT_NC_PhyloPgt2_corrected.input.txt','INSIGHT_NC_PhyloPgt2_corrected.log')
elif a.stage=='coding-prepare': run('bash','prepare_coding_cds.sh')
elif a.stage=='coding-hi':
  need('PhyloPG2_Nonsyn_ForINSIGHT_Poly_Theta_Lambda_AllSites.bed','poly.sorted.bed','fixed.sorted.bed','theta.sorted.bed','lambda.sorted.bed','NonsynDep2_HI_Genes.txt')
  run(sys.executable,'make_insight_hi_subset.py')
elif a.stage=='coding-fit': fit('INSIGHT_CDS_PhyloPgt2_input.txt','INSIGHT_CDS_PhyloPgt2.log')
elif a.stage=='beta-prep': run(sys.executable,'estimate_insight_beta.py')
elif a.stage=='beta-fit': run('./bin/INSIGHT-EM-v1.1','-b','neutral_beta.forBetas.ins','-v',logfile='neutral_beta.beta_em.log')
elif a.stage=='sensitivity-15': run(sys.executable,'run_insight_15pct.py')
elif a.stage=='gene-panel': run(sys.executable,'subset_insight_nearest_promoter.py')
elif a.stage=='gene-panel-fit': fit('INSIGHT_NC_PhyloPgt2_corrected.nearest_gene_panel.input.txt','INSIGHT_NC_PhyloPgt2_corrected.nearest_gene_panel.log')
elif a.stage=='check':
  for name in ['theta.sorted.bed','lambda.sorted.bed','make_INSIGHT.py','INSIGHT_CDS_PhyloPgt2_input.txt','INSIGHT_NC_PhyloPgt2_corrected.input.txt','INSIGHT_NC_PhyloPgt2_corrected.poly.polarization_stats.txt','INSIGHT_NC_PhyloPgt2_corrected.fixed.polarization_stats.txt']:
    print(('OK' if (w/name).is_file() else 'MISSING').ljust(9),name)
